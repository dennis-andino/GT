create
    definer = root@localhost procedure CREATE_CAREER(IN career_name varchar(100), IN ip varchar(50),
                                                     IN user_name varchar(25))
BEGIN
    DECLARE result INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            ROLLBACK;
            SET result = 1;
            SELECT result;
        END;
    DECLARE EXIT HANDLER FOR SQLWARNING
        BEGIN
            ROLLBACK;
            SET result = 1;
            SELECT result;
        END;
    START TRANSACTION;
    SET result = 0;
    INSERT INTO careers(description)VALUES(career_name);
    IF result = 0 THEN
        INSERT INTO courses(coursename, career) VALUES ('default_course',(select max(id) from careers));
        INSERT INTO binnacle (typeevent, description, date_event,hour_event, username, ip_address)
        VALUES ('Nuevo', concat('El usuario :',user_name,' agrego una carrera nueva :',career_name),CURDATE(),DATE_FORMAT(NOW( ), "%H:%i"), user_name, ip);
        COMMIT;
    ELSE
        ROLLBACK;
    END IF;
    SELECT result;
END;

