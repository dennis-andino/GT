create
    definer = root@localhost procedure CREATE_TUTORIA(IN schedule_ int, IN petitioner_ int, IN subject_ varchar(100),
                                                      IN details_ varchar(500), IN reservdate_ varchar(25),
                                                      IN requestdate_ varchar(25), IN filename_ varchar(100),
                                                      IN modality_ tinyint)
BEGIN
    DECLARE error, periodo INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            ROLLBACK;
            SET error = 1;
            SELECT error;
        END;
    DECLARE EXIT HANDLER FOR SQLWARNING
        BEGIN
            ROLLBACK;
            SET error = 1;
            SELECT error;
        END;
    START TRANSACTION;
    SET error = 0;
    select MAX(id) INTO periodo from periods;
    INSERT INTO tutorials(subject, details, reservdate, requestdate, filename, initialtime, finaltime, period_,
                          asignatura,approvedby, tutor, petitioner,modality)
    VALUES (subject_,
            details_,
            reservdate_,
            requestdate_,
            filename_,
            (select starttime from schedules where id = (select schedule from sch_tut where id = schedule_)),
            (select finishtime from schedules where id = (select schedule from sch_tut where id = schedule_)),
            periodo,
            (select course from sch_tut where id = schedule_),
            1,
            (select tutor from sch_tut where id = schedule_),
            petitioner_,modality_);
    IF error = 0 THEN
        INSERT INTO members_assistance(tutorial, student) VALUES ((select MAX(id) from tutorials), petitioner_);
        COMMIT;
    ELSE
        ROLLBACK;
    END IF;
    SELECT error;
END;

