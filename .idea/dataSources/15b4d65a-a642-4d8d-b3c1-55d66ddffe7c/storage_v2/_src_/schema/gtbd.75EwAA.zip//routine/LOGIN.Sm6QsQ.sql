create
    definer = root@localhost procedure LOGIN(IN _username varchar(25), IN ip_addr varchar(50))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            ROLLBACK;
        END;
    DECLARE EXIT HANDLER FOR SQLWARNING
        BEGIN
            ROLLBACK;
        END;
    START TRANSACTION;
    INSERT INTO binnacle (typeevent, description, date_event,hour_event, username, ip_address)
    VALUES ('login', concat('inicio de sesion'),CURDATE(),DATE_FORMAT(NOW( ), "%H:%i"), _username, ip_addr);
    COMMIT;
    SELECT l.id,
           l.username,
           l.pass,
           l.alias,
           l.email,
           l.career,
           l.birthDate,
           l.photo,
           r.announcement,
           r.ownsched,
           r.createtutoring,
           r.denytutoring,
           r.jointutoring,
           r.baseon,
        (SELECT name from institution where id=1) AS institution,
        (SELECT logo from institution where id=1) AS logo
    FROM logins l
             INNER JOIN roles r on l.userRole = r.id
    WHERE username = _username AND l.availability = 1;
END;

