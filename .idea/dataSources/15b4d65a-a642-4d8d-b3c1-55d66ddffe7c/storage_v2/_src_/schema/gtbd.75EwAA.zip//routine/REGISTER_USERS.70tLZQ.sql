create
    definer = root@localhost procedure REGISTER_USERS(IN username_ varchar(25), IN pass_ varchar(200), IN userRole_ int,
                                                      IN createOn_ varchar(20), IN lastUpdate_ varchar(20),
                                                      IN fullname_ varchar(50), IN alias_ varchar(50),
                                                      IN email_ varchar(200), IN phone_ varchar(100), IN campus_ int,
                                                      IN career_ int, IN account_ varchar(20),
                                                      IN birthDate_ varchar(20), IN admissionDate_ varchar(25),
                                                      IN ip_addr varchar(50))
BEGIN
    DECLARE id_user INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            ROLLBACK;
            SET id_user = 0;
            SELECT id_user;
        END;
    DECLARE EXIT HANDLER FOR SQLWARNING
        BEGIN
            ROLLBACK;
            SET id_user = 0;
            SELECT id_user;
        END;
    START TRANSACTION;
    SET id_user = 0;
    INSERT INTO logins(username, pass, userRole, createOn, lastUpdate, fullname, alias, email, phone, campus, career,
                       account, birthDate, admissionDate)
    VALUES (username_, pass_, userRole_, createOn_, lastUpdate_, fullname_, alias_, email_, phone_, campus_, career_,
            account_, birthDate_, admissionDate_);
    select id INTO id_user from logins where username = username_;
    IF (id_user > 0) THEN
        INSERT INTO binnacle (typeevent, description, date_event,hour_event, username, ip_address)
        VALUES ('Registro', concat('Registro de usuario ', alias_),CURDATE(),DATE_FORMAT(NOW( ), "%H:%i"), username_, ip_addr);
        COMMIT;
    ELSE
        ROLLBACK;
    END IF;
    SELECT id_user;
END;

