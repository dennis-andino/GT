create
    definer = root@localhost procedure WATCH_NOTIFICATIONS(IN userid int)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            ROLLBACK;
            SELECT id,subject,content,date FROM notifications WHERE destinationid=userid ORDER BY id DESC LIMIT 15;
        END;
    DECLARE EXIT HANDLER FOR SQLWARNING
        BEGIN
            ROLLBACK;
            SELECT id,subject,content,date FROM notifications WHERE destinationid=userid ORDER BY id DESC LIMIT 15;
        END;
START TRANSACTION;
    UPDATE notifications SET status=1 WHERE destinationid = userid AND status = 0;
    COMMIT;
    SELECT id,subject,content,date FROM notifications WHERE destinationid=userid ORDER BY id DESC LIMIT 15;
END;

