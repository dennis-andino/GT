create
    definer = root@localhost procedure aproval_tutoria(IN tutoriaid int, IN aproval_state int, IN coordinator int,
                                                       IN place varchar(500))
BEGIN
    DECLARE result INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            ROLLBACK;
            SET result = 1;
            SELECT result;
        END;
    DECLARE EXIT HANDLER FOR SQLWARNING
        BEGIN
            ROLLBACK;
            SET result = 1;
            SELECT result;
        END;
    START TRANSACTION;
    SET result = 0;
    UPDATE tutorials SET status=aproval_state , approvedby=coordinator,space=place WHERE id = tutoriaid;
    IF result = 0 THEN
        IF aproval_state=1 THEN
            INSERT INTO notifications(destinationid, subject, content, date)
            VALUES ((select petitioner from tutorials where id=tutoriaid),'Solicitud Aprobada',(SELECT CONCAT('La solicitud con asunto: ',subject,' , fue aprobada para el dia ',reservdate,' iniciando a las ',initialtime, ' impartida en : <br>', space) as resumo from tutorials where id=tutoriaid),(SELECT NOW()));
            INSERT INTO notifications(destinationid, subject, content, date)
            VALUES ((select tutor from tutorials where id=tutoriaid),'Solicitud Asignada',(SELECT CONCAT('Se le ha asignado una tutoria , con asunto: ',subject,' , para el dia ',reservdate,' iniciando a las ',initialtime, ' impartida en : <br>', space) as resumo from tutorials where id=tutoriaid),(SELECT NOW()));
        ELSE
            INSERT INTO notifications(destinationid, subject, content, date)
            VALUES ((select petitioner from tutorials where id=tutoriaid),'Solicitud Cancelada',(SELECT CONCAT('La solicitud con asunto: ',subject,' , fue cancelada a razon de : ', space) as resumo from tutorials where id=tutoriaid),(SELECT NOW()));
        END IF;
        COMMIT;
    ELSE
        ROLLBACK;
    END IF;
    SELECT result;
END;

