create
    definer = root@localhost procedure delete_tutoria(IN tutoriaid int, IN username_ varchar(25), IN ip_addr varchar(50))
BEGIN
    DECLARE result INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            ROLLBACK;
            SET result = 1;
            SELECT result;
        END;
    DECLARE EXIT HANDLER FOR SQLWARNING
        BEGIN
            ROLLBACK;
            SET result = 1;
            SELECT result;
        END;
    START TRANSACTION;
    SET result = 0;
    DELETE FROM members_assistance WHERE tutorial = tutoriaid;
    IF result = 0 THEN
        DELETE FROM tutorials WHERE id = tutoriaid;
        INSERT INTO binnacle (typeevent, description, date_event,hour_event, username, ip_address)
        VALUES ('Eliminacion', concat('El usuario :',username_,' elimino la solicitud de tutoria con id :',tutoriaid),CURDATE(),DATE_FORMAT(NOW( ), "%H:%i"), username_, ip_addr);
        COMMIT;
    END IF;
    SELECT result;
END;

