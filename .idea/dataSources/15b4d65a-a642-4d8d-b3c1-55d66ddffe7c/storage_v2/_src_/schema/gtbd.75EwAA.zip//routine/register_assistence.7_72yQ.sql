create
    definer = root@localhost procedure register_assistence(IN assistenceid int)
BEGIN
    DECLARE result INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            ROLLBACK;
            SET result = 1;
        END;
    DECLARE EXIT HANDLER FOR SQLWARNING
        BEGIN
            ROLLBACK;
            SET result = 1;
        END;
    START TRANSACTION;
    SET result = 0;
    UPDATE members_assistance SET assistance=1 WHERE id = assistenceid;
    IF result = 0 THEN
        COMMIT;
    END IF;
END;

