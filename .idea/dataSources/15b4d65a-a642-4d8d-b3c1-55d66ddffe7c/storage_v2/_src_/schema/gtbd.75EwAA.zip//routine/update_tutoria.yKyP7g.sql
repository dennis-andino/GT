create
    definer = root@localhost procedure update_tutoria(IN tutoriaid int, IN schedull int, IN reserv varchar(25),
                                                      IN space_ varchar(150))
BEGIN
    DECLARE result INT;
    DECLARE tutor_ INT;
    DECLARE tutsubject VARCHAR(100);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            ROLLBACK;
            SET result = 1;
            SELECT result;
        END;
    DECLARE EXIT HANDLER FOR SQLWARNING
        BEGIN
            ROLLBACK;
            SET result = 1;
            SELECT result;
        END;
    START TRANSACTION;
    SET result = 0;
    SELECT tutor INTO tutor_ from sch_tut where id = schedull;
    SELECT subject INTO tutsubject from tutorials where id = tutoriaid;
    UPDATE tutorials
    SET tutor=tutor_,
        asignatura=(select course from sch_tut where id = schedull),
        initialtime=(select starttime from schedules where id = (select schedule from sch_tut where id = schedull)),
        finaltime=(select finishtime from schedules where id = (select schedule from sch_tut where id = schedull)),
        reservdate=reserv,
        space=space_ WHERE id = tutoriaid;

    IF result = 0 THEN
        INSERT INTO notifications(destinationid, subject, content)
        VALUES (
                tutor_ ,
                'Tutoria reprogramada',
                (SELECT CONCAT('Se ha reprogramado la tutoria #',tutoriaid, ' con asunto : ',tutsubject,
                               ' para el dia: ',reserv)));
        INSERT INTO notifications(destinationid, subject, content)
        VALUES (
                   (select petitioner from tutorials where id=tutoriaid) ,
                   'Tutoria reprogramada',
                   (SELECT CONCAT('Se ha reprogramado la solicitud con asunto : ',tutsubject,' para el dia: ',reserv)));

        COMMIT;
    END IF;
    SELECT result;
END;

