create definer = root@localhost view get_evaluation as
select case `gtbd`.`tutorials`.`score`
           when 1 then 'Malo'
           when 2 then 'Regular'
           when 3 then 'Muy bueno'
           when 4 then 'Excelente'
           else 'Sin Calificar' end AS `evaluation`,
       count(0)                     AS `total`,
       `gtbd`.`tutorials`.`tutor`   AS `tutor`
from `gtbd`.`tutorials`
group by case `gtbd`.`tutorials`.`score`
             when 1 then 'Malo'
             when 2 then 'Regular'
             when 3 then 'Muy bueno'
             when 4 then 'Excelente'
             else 'Sin Calificar' end;

