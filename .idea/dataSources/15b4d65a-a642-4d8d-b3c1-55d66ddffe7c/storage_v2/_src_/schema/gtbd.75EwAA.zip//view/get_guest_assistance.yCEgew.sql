create definer = root@localhost view get_guest_assistance as
select distinct `t`.`id`                                        AS `id`,
                `c`.`coursename`                                AS `coursename`,
                `t`.`subject`                                   AS `subject`,
                `t`.`reservdate`                                AS `reservdate`,
                concat(`t`.`initialtime`, '-', `t`.`finaltime`) AS `schedule`,
                `l`.`alias`                                     AS `tutor`,
                `t`.`space`                                     AS `space`,
                `t`.`status`                                    AS `status`,
                if(`t`.`modality` = 0, 'Presencial', 'Virtual') AS `modalidad`,
                `t`.`score`                                     AS `score`,
                `t`.`petitioner`                                AS `petitioner`,
                `ma`.`student`                                  AS `student`
from (((`gtbd`.`members_assistance` `ma` join `gtbd`.`tutorials` `t` on (`ma`.`tutorial` = `t`.`id`)) join `gtbd`.`courses` `c` on (`t`.`asignatura` = `c`.`id`))
         join `gtbd`.`logins` `l` on (`t`.`tutor` = `l`.`id`));

