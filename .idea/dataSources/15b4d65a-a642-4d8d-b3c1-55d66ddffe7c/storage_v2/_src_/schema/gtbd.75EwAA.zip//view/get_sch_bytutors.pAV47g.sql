create definer = root@localhost view get_sch_bytutors as
select `sc`.`id`                                          AS `id`,
       `sc`.`tutor`                                       AS `tutor`,
       concat(`sch`.`starttime`, '-', `sch`.`finishtime`) AS `schedule`,
       `c`.`coursename`                                   AS `coursename`,
       `sc`.`availability`                                AS `availability`
from ((`gtbd`.`sch_tut` `sc` join `gtbd`.`schedules` `sch` on (`sc`.`schedule` = `sch`.`id`))
         join `gtbd`.`courses` `c` on (`sc`.`course` = `c`.`id`));

