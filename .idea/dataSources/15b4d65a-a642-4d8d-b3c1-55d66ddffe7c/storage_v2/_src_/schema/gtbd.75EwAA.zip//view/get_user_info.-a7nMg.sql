create definer = root@localhost view get_user_info as
select `l`.`id`            AS `id`,
       `l`.`username`      AS `username`,
       `l`.`fullname`      AS `fullname`,
       `l`.`alias`         AS `alias`,
       `l`.`email`         AS `email`,
       `l`.`phone`         AS `phone`,
       `l`.`account`       AS `account`,
       `l`.`birthDate`     AS `birthDate`,
       `l`.`admissionDate` AS `admissionDate`,
       `l`.`createOn`      AS `createOn`,
       `l`.`lastUpdate`    AS `lastUpdate`,
       `l`.`photo`         AS `photo`,
       `l`.`availability`  AS `availability`,
       `l`.`generalPoint`  AS `generalPoint`,
       `l`.`observations`  AS `observations`,
       `c`.`description`   AS `campus`,
       `c2`.`description`  AS `career`,
       `r`.`privilege`     AS `privilege`,
       `r`.`baseon`        AS `baseon`
from (((`gtbd`.`logins` `l` join `gtbd`.`campus` `c` on (`l`.`campus` = `c`.`id`)) join `gtbd`.`careers` `c2` on (`l`.`career` = `c2`.`id`))
         join `gtbd`.`roles` `r` on (`l`.`userRole` = `r`.`id`));

