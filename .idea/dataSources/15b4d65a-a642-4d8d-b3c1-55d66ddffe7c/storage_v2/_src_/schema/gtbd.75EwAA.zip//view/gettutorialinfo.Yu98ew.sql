create definer = root@localhost view gettutorialinfo as
select `t`.`id`                                        AS `id`,
       concat(`t`.`initialtime`, '-', `t`.`finaltime`) AS `schedule`,
       `pe`.`alias`                                    AS `studentname`,
       `tu`.`alias`                                    AS `tutorname`,
       `t`.`subject`                                   AS `subject`,
       `t`.`details`                                   AS `details`,
       `t`.`reservdate`                                AS `reservdate`,
       `t`.`requestdate`                               AS `requestdate`,
       `t`.`filename`                                  AS `filename`,
       `t`.`status`                                    AS `status`,
       `t`.`score`                                     AS `score`,
       `t`.`starttime`                                 AS `starttime`,
       `t`.`finishtime`                                AS `finishtime`,
       `t`.`stucomment`                                AS `stucomment`,
       `t`.`tutcomment`                                AS `tutcomment`,
       `t`.`modality`                                  AS `modality`,
       `t`.`space`                                     AS `space`,
       `p`.`description`                               AS `period`,
       `c`.`coursename`                                AS `coursename`,
       `co`.`alias`                                    AS `approvedby`
from (((((`gtbd`.`tutorials` `t` join `gtbd`.`periods` `p` on (`t`.`period_` = `p`.`id`)) join `gtbd`.`courses` `c` on (`t`.`asignatura` = `c`.`id`)) join `gtbd`.`logins` `co` on (`t`.`approvedby` = `co`.`id`)) join `gtbd`.`logins` `tu` on (`t`.`tutor` = `tu`.`id`))
         join `gtbd`.`logins` `pe` on (`t`.`petitioner` = `pe`.`id`));

