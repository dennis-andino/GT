create definer = root@localhost view userinfoedit as
select `l`.`id`           AS `id`,
       `l`.`fullname`     AS `fullname`,
       `l`.`email`        AS `email`,
       `l`.`phone`        AS `phone`,
       `l`.`birthDate`    AS `birthDate`,
       `l`.`account`      AS `account`,
       `l`.`career`       AS `careerid`,
       `ca`.`description` AS `career`,
       `r`.`privilege`    AS `privilege`,
       `r`.`id`           AS `roleid`,
       `c`.`id`           AS `campusid`,
       `c`.`description`  AS `campus`,
       `l`.`observations` AS `observations`
from (((`gtbd`.`logins` `l` join `gtbd`.`roles` `r` on (`l`.`userRole` = `r`.`id`)) join `gtbd`.`campus` `c` on (`l`.`campus` = `c`.`id`))
         join `gtbd`.`careers` `ca` on (`l`.`career` = `ca`.`id`));

