create definer = root@localhost view vw_alltutorials as
select `t`.`id`                                        AS `id`,
       `t`.`reservdate`                                AS `reservdate`,
       concat(`t`.`initialtime`, '-', `t`.`finaltime`) AS `schedule`,
       `t`.`status`                                    AS `status`,
       `c`.`coursename`                                AS `coursename`,
       `tu`.`alias`                                    AS `tutor`,
       `pe`.`alias`                                    AS `student`
from (((`gtbd`.`tutorials` `t` join `gtbd`.`courses` `c` on (`t`.`asignatura` = `c`.`id`)) join `gtbd`.`logins` `tu` on (`t`.`tutor` = `tu`.`id`))
         join `gtbd`.`logins` `pe` on (`t`.`petitioner` = `pe`.`id`));

