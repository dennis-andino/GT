create definer = root@localhost view vw_nextutorials as
select `t`.`id`                                        AS `id`,
       `t`.`petitioner`                                AS `petitioner`,
       `c`.`career`                                    AS `career`,
       `t`.`score`                                     AS `score`,
       `t`.`subject`                                   AS `subject`,
       `c`.`coursename`                                AS `coursename`,
       `t`.`reservdate`                                AS `reservdate`,
       `t`.`initialtime`                               AS `starttime`,
       `t`.`finaltime`                                 AS `finishtime`,
       `t`.`status`                                    AS `status`,
       `tu`.`alias`                                    AS `tutor`,
       if(`t`.`modality` = 0, 'Presencial', 'Virtual') AS `modalidad`,
       `t`.`space`                                     AS `space`
from ((`gtbd`.`tutorials` `t` join `gtbd`.`courses` `c` on (`t`.`asignatura` = `c`.`id`))
         join `gtbd`.`logins` `tu` on (`t`.`tutor` = `tu`.`id`));

