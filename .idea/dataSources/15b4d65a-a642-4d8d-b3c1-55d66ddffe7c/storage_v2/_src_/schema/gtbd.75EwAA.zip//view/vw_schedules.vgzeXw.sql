create definer = root@localhost view vw_schedules as
select `s`.`id`           AS `id`,
       `s`.`availability` AS `availability`,
       `s`.`tutor`        AS `tutorid`,
       `l`.`alias`        AS `tutor`,
       `s2`.`starttime`   AS `starttime`,
       `s2`.`finishtime`  AS `finishtime`,
       `c`.`id`           AS `course`,
       `c`.`coursename`   AS `coursename`
from (((`gtbd`.`sch_tut` `s` join `gtbd`.`logins` `l` on (`s`.`tutor` = `l`.`id`)) join `gtbd`.`schedules` `s2` on (`s`.`schedule` = `s2`.`id`))
         join `gtbd`.`courses` `c` on (`s`.`course` = `c`.`id`));

