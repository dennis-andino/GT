create definer = root@localhost view vw_tutbytutors as
select `t`.`id`                                        AS `id`,
       `pe`.`alias`                                    AS `student`,
       `c`.`coursename`                                AS `coursename`,
       `t`.`subject`                                   AS `subject`,
       `t`.`details`                                   AS `details`,
       `t`.`filename`                                  AS `filename`,
       `t`.`reservdate`                                AS `reservdate`,
       concat(`t`.`initialtime`, '-', `t`.`finaltime`) AS `schedule`,
       `t`.`status`                                    AS `status`,
       `t`.`score`                                     AS `score`,
       `tu`.`id`                                       AS `tutorid`
from (((`gtbd`.`tutorials` `t` join `gtbd`.`courses` `c` on (`t`.`asignatura` = `c`.`id`)) join `gtbd`.`logins` `tu` on (`t`.`tutor` = `tu`.`id`))
         join `gtbd`.`logins` `pe` on (`t`.`petitioner` = `pe`.`id`));

